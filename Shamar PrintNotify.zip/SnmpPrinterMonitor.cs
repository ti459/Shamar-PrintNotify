﻿using System;

namespace Shamar_PrintNotify
{
    public class SnmpPrinterMonitor : IDisposable
    {
        private readonly SnmpService _snmpService;
        private readonly string _ipAddress;

        // IMPORTANTE:
        // Usamos explicitamente System.Threading.Timer
        // para evitar conflito com System.Windows.Forms.Timer.
        private System.Threading.Timer? _timer;

        private int _ultimoPrinterStatus = -1;
        private int _ultimoDeviceStatus = -1;

        public bool IsRunning { get; private set; }

        public event Action<int>? PrinterStatusChanged;
        public event Action? PrinterStarted;
        public event Action? PrinterStopped;

        public SnmpPrinterMonitor(string ipAddress)
        {
            _ipAddress = ipAddress ?? string.Empty;

            _snmpService = new SnmpService();
        }

        public void Start()
        {
            if (IsRunning)
            {
                return;
            }

            if (string.IsNullOrWhiteSpace(_ipAddress))
            {
                return;
            }

            IsRunning = true;

            Console.WriteLine("SNMP MONITOR: iniciado.");
            Console.WriteLine($"SNMP MONITOR: IP = {_ipAddress}");

            _timer = new System.Threading.Timer(
                Consultar,
                null,
                TimeSpan.Zero,
                TimeSpan.FromSeconds(2));
        }

        private void Consultar(object? state)
        {
            try
            {
                if (!IsRunning)
                {
                    return;
                }

                SnmpPrinterStatus status =
                    _snmpService.GetStatus(_ipAddress);

                Console.WriteLine("SNMP MONITOR: consulta realizada.");
                Console.WriteLine($"SNMP MONITOR: Respondeu = {status.Respondeu}");

                if (!status.Respondeu)
                {
                    return;
                }

                Console.WriteLine(
                    $"SNMP MONITOR: PrinterStatus = {status.PrinterStatus}");

                Console.WriteLine(
                    $"SNMP MONITOR: DeviceStatus = {status.DeviceStatus}");

                Console.WriteLine(
                    $"SNMP MONITOR: DeviceErrors = {status.DeviceErrors}");

                Console.WriteLine(
                    $"SNMP MONITOR: Description = {status.Description}");

                int atualPrinterStatus =
                    status.PrinterStatus;

                int atualDeviceStatus =
                    status.DeviceStatus;

                Console.WriteLine(
                    $"SNMP MONITOR: PrinterStatus recebido = {atualPrinterStatus}");

                Console.WriteLine(
                    $"SNMP MONITOR: DeviceStatus recebido = {atualDeviceStatus}");

                // Primeira leitura
                if (_ultimoPrinterStatus == -1)
                {
                    _ultimoPrinterStatus =
                        atualPrinterStatus;

                    _ultimoDeviceStatus =
                        atualDeviceStatus;

                    Console.WriteLine(
                        $"SNMP MONITOR: primeira leitura = {atualPrinterStatus}");

                    PrinterStatusChanged?.Invoke(
                        atualPrinterStatus);

                    return;
                }

                // Detecta mudança de estado
                if (atualPrinterStatus != _ultimoPrinterStatus ||
                    atualDeviceStatus != _ultimoDeviceStatus)
                {
                    int anteriorPrinterStatus =
                        _ultimoPrinterStatus;

                    int anteriorDeviceStatus =
                        _ultimoDeviceStatus;

                    Console.WriteLine(
                        "SNMP MONITOR: mudança de estado detectada.");

                    Console.WriteLine(
                        $"SNMP MONITOR: PrinterStatus anterior = {anteriorPrinterStatus}");

                    Console.WriteLine(
                        $"SNMP MONITOR: PrinterStatus atual = {atualPrinterStatus}");

                    Console.WriteLine(
                        $"SNMP MONITOR: DeviceStatus anterior = {anteriorDeviceStatus}");

                    Console.WriteLine(
                        $"SNMP MONITOR: DeviceStatus atual = {atualDeviceStatus}");

                    _ultimoPrinterStatus =
                        atualPrinterStatus;

                    _ultimoDeviceStatus =
                        atualDeviceStatus;

                    PrinterStatusChanged?.Invoke(
                        atualPrinterStatus);

                    // =============================================
                    // IMPRESSORA ENTROU EM ATIVIDADE
                    // 3 -> 4
                    // =============================================

                    if (anteriorPrinterStatus == 3 &&
                        atualPrinterStatus == 4)
                    {
                        PrinterStarted?.Invoke();
                    }

                    // =============================================
                    // IMPRESSORA VOLTOU AO NORMAL
                    // 4 -> 3
                    // =============================================

                    if (anteriorPrinterStatus == 4 &&
                        atualPrinterStatus == 3)
                    {
                        PrinterStopped?.Invoke();
                    }
                }
            }
            catch (Exception ex)
            {
                // Não interromper o monitoramento
                // caso uma consulta SNMP falhe.

                Console.WriteLine(
                    $"SNMP MONITOR: erro na consulta: {ex.Message}");
            }
        }

        public void Stop()
        {
            if (!IsRunning)
            {
                return;
            }

            IsRunning = false;

            if (_timer != null)
            {
                _timer.Dispose();
                _timer = null;
            }

            Console.WriteLine("SNMP MONITOR: parado.");
        }

        public void Dispose()
        {
            Stop();
        }
    }
}
